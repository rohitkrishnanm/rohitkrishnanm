import React from 'react'

import 'react-day-picker/lib/style.css'

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
